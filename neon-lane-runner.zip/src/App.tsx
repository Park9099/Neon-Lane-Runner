import React, { useState, useEffect, useRef, ChangeEvent } from 'react';
import { GamePhase, GameStats, UserAccount, SeasonState } from './types';
import { GameCanvas } from './components/GameCanvas';
import { Leaderboard } from './components/Leaderboard';
import { AuthPanel } from './components/AuthPanel';
import { setMuted, getMuted, setVolume, getVolume, sounds } from './utils/audio';
import { getSeasonState, loadAccounts } from './utils/seasonManager';
import { motion, AnimatePresence } from 'motion/react';
import {
  Trophy,
  Zap,
  Volume2,
  VolumeX,
  Play,
  RotateCcw,
  Shield,
  Coins,
  Activity,
  Pause,
  HelpCircle,
  Gauge,
  Sparkles,
  Lock,
  UserCheck
} from 'lucide-react';

export default function App() {
  const [phase, setPhase] = useState<GamePhase>('MENU');
  const [stats, setStats] = useState<GameStats>({
    score: 0,
    coins: 0,
    distance: 0,
    multiplier: 1,
    multiplierEndTime: 0,
    shieldActive: false,
    shieldEndTime: 0,
    lives: 3,
    speed: 8,
  });

  const [isPaused, setIsPaused] = useState(false);
  const [muted, setMutedState] = useState(getMuted());
  const [volume, setVolumeState] = useState(getVolume());
  const [showTutorial, setShowTutorial] = useState(false);

  // Authenticated User states
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);

  // Seasonal System states
  const [seasonInfo, setSeasonInfo] = useState<SeasonState>({
    currentSeason: 1,
    endsAt: Date.now() + 30 * 24 * 3600 * 1000,
    previousChampion: null,
    history: []
  });

  // High score tracking for leaderboard submission
  const [finalScore, setFinalScore] = useState<number | null>(null);
  const [maxMultiplier, setMaxMultiplier] = useState<number>(1);

  // Time-remaining tickers for active powerups
  const [shieldTimeLeft, setShieldTimeLeft] = useState(0);
  const [multiplierTimeLeft, setMultiplierTimeLeft] = useState(0);

  // Load active user session & season on mount
  useEffect(() => {
    // 1. Load active Season State
    const activeSeason = getSeasonState();
    setSeasonInfo(activeSeason);

    // 2. Load active logged in user from session if preserved
    const preservedUser = sessionStorage.getItem('neon_runner_current_user');
    if (preservedUser) {
      try {
        const parsed = JSON.parse(preservedUser);
        // fetch fresh account properties from localStorage
        const accounts = loadAccounts();
        const freshUser = accounts.find(acc => acc.username.toLowerCase() === parsed.username.toLowerCase());
        if (freshUser) {
          setCurrentUser(freshUser);
        }
      } catch (e) {
        // fail gracefully
      }
    }
  }, []);

  // Listen to power-up timers
  useEffect(() => {
    if (phase !== 'PLAYING' || isPaused) return;

    const timer = setInterval(() => {
      const now = Date.now();
      if (stats.shieldActive) {
        setShieldTimeLeft(Math.max(0, Math.ceil((stats.shieldEndTime - now) / 1000)));
      } else {
        setShieldTimeLeft(0);
      }

      if (stats.multiplier > 1) {
        setMultiplierTimeLeft(Math.max(0, Math.ceil((stats.multiplierEndTime - now) / 1000)));
      } else {
        setMultiplierTimeLeft(0);
      }
    }, 200);

    return () => clearInterval(timer);
  }, [phase, isPaused, stats.shieldActive, stats.shieldEndTime, stats.multiplier, stats.multiplierEndTime]);

  const handleStatsChange = (newStats: GameStats) => {
    setStats(newStats);
    if (newStats.multiplier > maxMultiplier) {
      setMaxMultiplier(newStats.multiplier);
    }
  };

  const handleGameOver = (score: number) => {
    setFinalScore(score);
    setPhase('GAMEOVER');

    // Automatically reward any coins collected during play back to active profile!
    if (currentUser && score > 0) {
      const coinReward = stats.coins; // 1-to-1 conversion
      const accounts = loadAccounts();
      const updated = accounts.map(acc => {
        if (acc.username.toLowerCase() === currentUser.username.toLowerCase()) {
          return {
            ...acc,
            coinsCollected: acc.coinsCollected + coinReward,
            highScore: Math.max(acc.highScore, score)
          };
        }
        return acc;
      });
      // Save changes back
      localStorage.setItem('neon_runner_accounts', JSON.stringify(updated));
      const updatedUser = updated.find(acc => acc.username.toLowerCase() === currentUser.username.toLowerCase());
      if (updatedUser) {
        setCurrentUser(updatedUser);
        sessionStorage.setItem('neon_runner_current_user', JSON.stringify(updatedUser));
      }
    }
  };

  const startGame = () => {
    // Blur any active inputs to return keyboard focus to the game/window
    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
    window.focus();

    // Resume audio context on user interaction
    sounds.playLaneChange();
    setPhase('PLAYING');
    setIsPaused(false);
    setFinalScore(null);
    setMaxMultiplier(1);
  };

  const toggleMute = () => {
    const nextMuted = !muted;
    setMuted(nextMuted);
    setMutedState(nextMuted);
    sounds.playCoin();
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    setVolumeState(val);
    if (val > 0 && muted) {
      setMuted(false);
      setMutedState(false);
    }
  };

  // Auth logins & callbacks
  const handleUserLogin = (user: UserAccount) => {
    setCurrentUser(user);
    sessionStorage.setItem('neon_runner_current_user', JSON.stringify(user));
  };

  const handleUserLogout = () => {
    setCurrentUser(null);
    sessionStorage.removeItem('neon_runner_current_user');
    sounds.playGameOver();
  };

  const handleSkinSelect = (skinId: string) => {
    if (currentUser) {
      const nextUser = { ...currentUser, selectedSkin: skinId };
      setCurrentUser(nextUser);
      sessionStorage.setItem('neon_runner_current_user', JSON.stringify(nextUser));
    }
  };

  // Season end trigger
  const handleSeasonEnded = (nextState: SeasonState) => {
    setSeasonInfo(nextState);
    // Reload user to sync potential newly unlocked Champion skin
    if (currentUser) {
      const accounts = loadAccounts();
      const reloadedUser = accounts.find(acc => acc.username.toLowerCase() === currentUser.username.toLowerCase());
      if (reloadedUser) {
        setCurrentUser(reloadedUser);
        sessionStorage.setItem('neon_runner_current_user', JSON.stringify(reloadedUser));
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#04010a] text-slate-100 flex flex-col font-sans select-none overflow-x-hidden relative" id="neon-app-root">
      {/* Decorative Neon ambient flares */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full filter blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-pink-500/10 rounded-full filter blur-[100px] pointer-events-none" />

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-5 md:py-8 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: Main Game Console */}
        <div className="lg:col-span-7 xl:col-span-8 flex flex-col gap-4 w-full">
          
          {/* Header Dashboard panel */}
          <header className="flex justify-between items-center bg-slate-900/45 p-4 rounded-xl border border-white/5 backdrop-blur-md">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 animate-pulse shadow-[0_0_8px_#00f0ff]" />
                <h1 className="text-xl md:text-2xl font-black tracking-wider bg-gradient-to-r from-cyan-400 via-pink-400 to-purple-400 bg-clip-text text-transparent font-sans">
                  NEON RUNNER
                </h1>
              </div>
              <p className="text-[11px] font-mono text-slate-400 tracking-wider">
                COSMIC SPEEDWAYS • 시즌 {seasonInfo.currentSeason} 리그 진행 중
              </p>
            </div>

            {/* In-game volume controller */}
            <div className="flex items-center gap-2.5 bg-slate-950/60 py-1.5 px-3 rounded-lg border border-white/5">
              <button
                onClick={toggleMute}
                className="text-slate-400 hover:text-white transition-colors cursor-pointer animate-none"
                title={muted ? '음소거 해제' : '음소거'}
              >
                {muted ? <VolumeX className="w-4 h-4 text-pink-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={muted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-16 md:w-20 accent-cyan-400 h-1 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>
          </header>

          {/* ACTIVE PLAYING HUD */}
          {phase === 'PLAYING' && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {/* Score card */}
              <div className="bg-slate-900/50 p-3 rounded-xl border border-white/5 backdrop-blur-md flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-mono text-slate-400">SCORE</p>
                  <p className="text-xl font-bold font-mono text-white tracking-tight">
                    {stats.score.toLocaleString()}
                  </p>
                </div>
                {stats.multiplier > 1 && (
                  <span className="bg-purple-500/20 text-purple-400 border border-purple-500/30 text-[10px] px-1.5 py-0.5 rounded font-mono font-bold animate-bounce flex items-center gap-0.5">
                    <Zap className="w-3 h-3" /> 2X
                  </span>
                )}
              </div>

              {/* Lives tracker */}
              <div className="bg-slate-900/50 p-3 rounded-xl border border-white/5 backdrop-blur-md flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-mono text-slate-400 font-medium">SHIELD CORE</p>
                  <div className="flex gap-1.5 mt-1">
                    {[0, 1, 2].map((idx) => (
                      <div
                        key={idx}
                        className={`w-5 h-2.5 rounded-sm border transition-all duration-300 ${
                          idx < stats.lives
                            ? 'bg-gradient-to-r from-pink-500 to-rose-500 border-pink-400 shadow-[0_0_8px_rgba(236,72,153,0.5)]'
                            : 'bg-transparent border-slate-700'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <Activity className="w-4 h-4 text-pink-400" />
              </div>

              {/* Coins counts */}
              <div className="bg-slate-900/50 p-3 rounded-xl border border-white/5 backdrop-blur-md flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-mono text-slate-400">ENERGY CORES</p>
                  <p className="text-xl font-bold font-mono text-amber-400">
                    {stats.coins}
                  </p>
                </div>
                <Coins className="w-4 h-4 text-amber-400" />
              </div>

              {/* Distance or Speedometer */}
              <div className="bg-slate-900/50 p-3 rounded-xl border border-white/5 backdrop-blur-md flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-mono text-slate-400">SPEED</p>
                  <p className="text-xl font-bold font-mono text-cyan-400">
                    {stats.speed * 10} <span className="text-xs text-slate-400">km/h</span>
                  </p>
                </div>
                <Gauge className="w-4 h-4 text-cyan-400" />
              </div>
            </div>
          )}

          {/* GAME VIEWPORT BLOCK */}
          <div className="relative aspect-[3/4] max-h-[580px] w-full bg-slate-950 rounded-xl overflow-hidden border border-white/10 shadow-[0_0_30px_rgba(0,240,255,0.04)]">
            
            {/* Embedded core Game Canvas */}
            <GameCanvas
              phase={phase}
              onStatsChange={handleStatsChange}
              onGameOver={handleGameOver}
              isPaused={isPaused}
              selectedSkinId={currentUser?.selectedSkin || 'default'}
            />

            {/* DYNAMIC SCREENS OVERLAYS */}
            <AnimatePresence mode="wait">
              
              {/* 1. MENU STATE SCREEN */}
              {phase === 'MENU' && (
                <motion.div
                  key="menu"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-20"
                >
                  <motion.div
                    initial={{ scale: 0.9, y: 15 }}
                    animate={{ scale: 1, y: 0 }}
                    transition={{ type: 'spring', damping: 12 }}
                  >
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded-full text-[11px] font-mono mb-4 tracking-wider">
                      <Sparkles className="w-3.5 h-3.5" /> 100% 무인 AI봇 배제 청정 리그
                    </div>
                    
                    <h2 className="text-4xl md:text-5xl font-black tracking-wider text-white uppercase drop-shadow-[0_0_15px_rgba(0,240,255,0.4)] mb-2">
                      NEON RUNNER
                    </h2>
                    
                    <p className="text-slate-400 text-xs max-w-sm mx-auto mb-8 leading-relaxed">
                      장애물을 피하며 코어를 수집하세요!<br />
                      <strong>시즌 우승자(1등)</strong>에겐 전설적인 은빛 전용 우승 스킨이 즉시 지급됩니다!
                    </p>

                    <div className="flex flex-col sm:flex-row gap-3 justify-center mb-6">
                      {currentUser ? (
                        <button
                          onClick={startGame}
                          className="px-8 py-3.5 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 active:scale-95 text-slate-950 font-black tracking-widest text-xs uppercase rounded-xl shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <Play className="w-4 h-4 fill-current" /> 비행 시동 걸기
                        </button>
                      ) : (
                        <div className="p-4 bg-slate-900 rounded-xl border border-dashed border-white/15 max-w-xs">
                          <p className="text-xs font-semibold text-pink-400 mb-2 flex items-center justify-center gap-1">
                            <Lock className="w-3.5 h-3.5" /> 조종실 탑승 제한
                          </p>
                          <p className="text-[11px] text-slate-400 mb-3 leading-snug">오른쪽 패널에서 신규 조종사를 등록하거나 로그인한 후에 비행에 합류하실 수 있습니다!</p>
                        </div>
                      )}
                      
                      <button
                        onClick={() => setShowTutorial(true)}
                        className="px-6 py-3.5 bg-slate-900 hover:bg-slate-800 text-slate-300 font-bold text-xs tracking-wider rounded-xl border border-white/10 flex items-center justify-center gap-2 cursor-pointer transition-all"
                      >
                        <HelpCircle className="w-4 h-4" /> 가이드 & 보상 보기
                      </button>
                    </div>

                    <p className="text-[10px] text-slate-500 font-mono">
                      * 방향키 또는 A/D 키, 혹은 양쪽 화면 터치로 컨트롤
                    </p>
                  </motion.div>
                </motion.div>
              )}

              {/* 2. GAME OVER STATE SCREEN */}
              {phase === 'GAMEOVER' && (
                <motion.div
                  key="gameover"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center overflow-y-auto z-20"
                >
                  <motion.div
                    initial={{ scale: 0.9, y: 15 }}
                    animate={{ scale: 1, y: 0 }}
                    className="w-full max-w-md my-auto"
                  >
                    <span className="text-[10px] font-mono tracking-widest text-pink-500 uppercase font-bold bg-pink-500/10 border border-pink-500/20 px-2.5 py-1 rounded">
                      PILOT UNCONSCIOUS
                    </span>
                    
                    <h2 className="text-3xl md:text-4xl font-black text-transparent bg-gradient-to-r from-red-500 to-pink-500 bg-clip-text mt-4 mb-5 uppercase tracking-wide">
                      MISSION FAILED
                    </h2>

                    {/* Final game statistics board */}
                    <div className="grid grid-cols-2 gap-3 mb-6 bg-slate-900/60 p-4 rounded-xl border border-white/5 text-left">
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono">SCORE</span>
                        <p className="text-xl font-bold font-mono text-cyan-400">
                          {finalScore?.toLocaleString()} pts
                        </p>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono">DISTANCE</span>
                        <p className="text-xl font-bold font-mono text-white">
                          {Math.floor(stats.distance).toLocaleString()} m
                        </p>
                      </div>
                      <div className="border-t border-white/5 pt-2 mt-2">
                        <span className="text-[10px] text-slate-400 font-mono">ENERGY CORES REWARD</span>
                        <p className="text-sm font-bold font-mono text-amber-400">
                          +{stats.coins} Coins 지급 완료
                        </p>
                      </div>
                      <div className="border-t border-white/5 pt-2 mt-2">
                        <span className="text-[10px] text-slate-400 font-mono">MAX STREAK</span>
                        <p className="text-sm font-bold font-mono text-purple-400">
                          {maxMultiplier}X 배율
                        </p>
                      </div>
                    </div>

                    {/* Integrated Leaderboard Submit Form */}
                    {finalScore !== null && (
                      <div className="mb-6">
                        <Leaderboard
                          currentSeason={seasonInfo.currentSeason}
                          currentUser={currentUser}
                          onSeasonEnded={handleSeasonEnded}
                          scoreToSubmit={finalScore}
                          maxMultiplierReached={maxMultiplier}
                          onScoreSubmitted={() => {}}
                          inline={true}
                        />
                      </div>
                    )}

                    {/* Buttons */}
                    <div className="flex flex-col sm:flex-row gap-3 justify-center">
                      <button
                        onClick={startGame}
                        className="px-6 py-3 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-bold rounded-lg text-xs tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      >
                        <RotateCcw className="w-4 h-4" /> 다시 이륙하기
                      </button>
                      <button
                        onClick={() => setPhase('MENU')}
                        className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg text-xs tracking-wider border border-white/5 transition-all cursor-pointer"
                      >
                        메인 메뉴로
                      </button>
                    </div>
                  </motion.div>
                </motion.div>
              )}

              {/* 3. IN-GAME PAUSED SCREEN */}
              {isPaused && phase === 'PLAYING' && (
                <motion.div
                  key="paused"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-10"
                >
                  <h3 className="text-2xl font-black tracking-widest text-white mb-2 uppercase">
                    SYSTEM PAUSED
                  </h3>
                  <p className="text-slate-400 text-xs mb-6 max-w-xs">
                    함선 에너지를 보존 중입니다. 계속 비행하려면 일시 정지를 해제해 주세요.
                  </p>
                  <button
                    onClick={() => setIsPaused(false)}
                    className="px-6 py-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black rounded-lg text-xs tracking-wider flex items-center gap-1.5 cursor-pointer transition-all"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" /> 비행 재개
                  </button>
                </motion.div>
              )}
            </AnimatePresence>

            {/* In-Game HUD Active Timers Overlay */}
            {phase === 'PLAYING' && (
              <div className="absolute top-4 right-4 flex flex-col gap-2 z-10 select-none pointer-events-none">
                {/* Shield Time */}
                {stats.shieldActive && (
                  <div className="flex items-center gap-2 bg-cyan-950/85 px-3 py-1.5 rounded-lg border border-cyan-500/30 text-[10px] font-mono shadow-[0_0_12px_rgba(6,182,212,0.25)]">
                    <Shield className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                    <div className="text-left">
                      <div className="text-slate-400 leading-tight">SHIELD</div>
                      <div className="text-cyan-400 font-bold font-mono">{shieldTimeLeft}s</div>
                    </div>
                  </div>
                )}

                {/* Multiplier Time */}
                {stats.multiplier > 1 && (
                  <div className="flex items-center gap-2 bg-purple-950/85 px-3 py-1.5 rounded-lg border border-purple-500/30 text-[10px] font-mono shadow-[0_0_12px_rgba(168,85,247,0.25)]">
                    <Zap className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
                    <div className="text-left">
                      <div className="text-slate-400 leading-tight">DOUBLE</div>
                      <div className="text-purple-400 font-bold font-mono">{multiplierTimeLeft}s</div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* In-game Pause clicker */}
            {phase === 'PLAYING' && !isPaused && (
              <button
                onClick={() => setIsPaused(true)}
                className="absolute bottom-4 right-4 bg-slate-950/85 hover:bg-slate-900 border border-white/10 p-2.5 rounded-lg text-slate-300 hover:text-white transition-all z-10 cursor-pointer"
                title="일시 정지"
              >
                <Pause className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: Sidebar (AuthPanel, Leaderboard, General stats) */}
        <div className="lg:col-span-5 xl:col-span-4 flex flex-col gap-5 w-full">
          
          {/* USER PROFILE & SKINS BLOCK */}
          <AuthPanel
            currentUser={currentUser}
            onLogin={handleUserLogin}
            onLogout={handleUserLogout}
            onSkinSelect={handleSkinSelect}
          />

          {/* ACTIVE SEASON LEADERBOARD */}
          <Leaderboard
            currentSeason={seasonInfo.currentSeason}
            currentUser={currentUser}
            onSeasonEnded={handleSeasonEnded}
          />
          
        </div>
      </main>

      {/* FOOTER */}
      <footer className="border-t border-white/5 py-4 text-center text-xs text-slate-500 font-mono tracking-wider mt-auto select-none pointer-events-none">
        NEON LANE RUNNER • CREATED IN DEEPMIND AI STUDIO BUILD
      </footer>

      {/* DETAIL TUTORIAL MODAL (Opened from main menu) */}
      <AnimatePresence>
        {showTutorial && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-6 z-50 overflow-y-auto"
            onClick={() => setShowTutorial(false)}
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-slate-900 border border-white/10 rounded-2xl p-6 max-w-md w-full text-slate-300 relative"
            >
              <h3 className="text-xl font-bold text-white mb-2 flex items-center gap-2 font-sans">
                <Sparkles className="w-5 h-5 text-cyan-400" /> 신규 조종사 가이드 & 보상
              </h3>
              
              <div className="space-y-4 text-xs leading-relaxed my-4 text-slate-400">
                <p>
                  <strong>네온 레인 러너 (Neon Lane Runner)</strong>에 동참하신 것을 환영합니다!
                  이번 업데이트에서는 완전 무인화 청정 리그(AI 봇 비탑재) 및 독창적인 시즌제 스킨 시스템이 새로 도입되었습니다.
                </p>
                
                <h4 className="text-white font-semibold text-xs font-mono uppercase text-cyan-400">시즌제 리그 및 우승자 스킨 보상:</h4>
                <ul className="list-disc pl-5 space-y-1.5">
                  <li><strong>1달 주기 자동 리셋:</strong> 매달 1일 정각에 시즌이 정각 초기화되며, 역대 전당 기록에 보관됩니다.</li>
                  <li><strong>👑 최종 1위 독점 보상:</strong> 시즌이 마감되는 시점에 명예의 전당 1위를 수성하고 있는 계정에게는 <strong>[네온 팬텀] 스킨</strong>이 영구 잠금 해제되어 외형 특전으로 적용됩니다.</li>
                  <li><strong>스킨 외형 교체:</strong> 프로필에서 선택한 스킨에 맞추어 주행 시 플레이어 제트기의 기체 색상, 내부 코어, 플라즈마 화염 스러스터 파티클 효과가 즉각 교체됩니다!</li>
                </ul>

                <h4 className="text-white font-semibold text-xs font-mono uppercase text-pink-400">조작 방법 리마인드:</h4>
                <ul className="list-disc pl-5 space-y-1.5">
                  <li><strong>키보드:</strong> 좌측 이동은 <kbd className="px-1.5 py-0.5 bg-slate-800 border border-white/10 rounded text-white text-[10px]">A</kbd> 키나 <kbd className="px-1.5 py-0.5 bg-slate-800 border border-white/10 rounded text-white text-[10px]">←</kbd> 키, 우측 이동은 <kbd className="px-1.5 py-0.5 bg-slate-800 border border-white/10 rounded text-white text-[10px]">D</kbd> 키나 <kbd className="px-1.5 py-0.5 bg-slate-800 border border-white/10 rounded text-white text-[10px]">→</kbd> 키를 눌러 차선을 교체하세요.</li>
                  <li><strong>마우스/터치:</strong> 화면의 왼쪽 반을 누르면 좌측으로, 오른쪽 반을 누르면 우측으로 이동합니다.</li>
                </ul>
              </div>

              <button
                onClick={() => setShowTutorial(false)}
                className="w-full mt-2 py-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-xl text-xs tracking-wider cursor-pointer transition-all"
              >
                조종실로 돌아가기
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
