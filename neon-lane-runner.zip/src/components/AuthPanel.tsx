import React, { useState, useEffect } from 'react';
import { UserAccount, SkinDefinition, SkinId } from '../types';
import { loadAccounts, saveAccounts } from '../utils/seasonManager';
import { Shield, Sparkles, User, Lock, LogIn, UserPlus, LogOut, Coins, Star, Trophy } from 'lucide-react';
import { sounds } from '../utils/audio';

// Available Skins Definitions
export const SKINS_LIST: SkinDefinition[] = [
  {
    id: 'default',
    name: '네온 블레이드 제트 (기본형)',
    primaryColor: '#0a0a18',
    secondaryColor: '#00f0ff',
    glowColor: '#00f0ff',
    description: '기본 보급용 우주 전투기. 가볍고 민첩합니다.',
    howToUnlock: '가입시 기본 제공'
  },
  {
    id: 'gold_cyber',
    name: '골드 사이버 디스트로이어',
    primaryColor: '#1a1505',
    secondaryColor: '#ffd700',
    glowColor: '#ffaa00',
    description: '호화로운 황금빛 합금과 고에너지 코어 추진기가 탑재된 한정판 기체.',
    howToUnlock: '500 에너지 코어(Coins)로 교환 가능'
  },
  {
    id: 'champion_phantom',
    name: '네온 팬텀 (시즌 우승자 전용)',
    primaryColor: '#0d0115',
    secondaryColor: '#ff00aa',
    glowColor: '#bf55ec',
    description: '시즌 명예의 전당 1위에 오른 파일럿에게만 지급되는 진정한 전설의 은밀한 보라빛 함선.',
    howToUnlock: '시즌 최종 순위 1위 달성 시 지급'
  },
  {
    id: 'dev_exclusive',
    name: '네온 매트릭스 (개발자 전용)',
    primaryColor: '#020c03',
    secondaryColor: '#39ff14',
    glowColor: '#39ff14',
    description: '메인 시스템 개발자만을 위해 코딩된 최첨단 사이버 공간 장악용 기체.',
    howToUnlock: '개발자(AKS13551) 전용 보안 승인'
  },
  {
    id: 'champ_3wins',
    name: '갤럭시 템페스트 (통산 3회 우승)',
    primaryColor: '#030d22',
    secondaryColor: '#00ffff',
    glowColor: '#0088ff',
    description: '은하계를 뒤흔드는 무자비한 청색 플라즈마 에너지를 수집해 제작된 통산 3회 우승자 전용 함선.',
    howToUnlock: '시즌 최종 우승 총 3회 달성 시 지급'
  },
  {
    id: 'champ_5wins',
    name: '스타 코즈믹 노바 (통산 5회 우승)',
    primaryColor: '#220d03',
    secondaryColor: '#ff7700',
    glowColor: '#ffaa00',
    description: '초신성 폭발 에너지 코어가 장착되어 찬란한 주황 태양빛을 뿜어내는 통산 5회 우승자 전용 함선.',
    howToUnlock: '시즌 최종 우승 총 5회 달성 시 지급'
  },
  {
    id: 'champ_7wins',
    name: '네온 하이퍼 드라이브 (통산 7회 우승)',
    primaryColor: '#03221d',
    secondaryColor: '#00ffcc',
    glowColor: '#00cca3',
    description: '차원 도약을 일으키며 시공간의 한계를 초월하는 전설적인 청록빛 통산 7회 우승자 전용 함선.',
    howToUnlock: '시즌 최종 우승 총 7회 달성 시 지급'
  },
  {
    id: 'champ_10wins',
    name: '디멘셔널 어비스 보이드 (통산 10회 우승)',
    primaryColor: '#0c0012',
    secondaryColor: '#e0115f',
    glowColor: '#ff003c',
    description: '어두운 심연의 블랙홀 에너지를 통제하여 공간을 가르는 진홍빛 우주의 절대 강자 10회 우승자 전용 기체.',
    howToUnlock: '시즌 최종 우승 총 10회 달성 시 지급'
  }
];

export type Language = 'ko' | 'en' | 'ja';

export const TRANSLATIONS: Record<Language, {
  selectLanguage: string;
  loginTitle: string;
  registerTitle: string;
  switchToRegister: string;
  switchToLogin: string;
  usernamePlaceholder: string;
  passwordPlaceholder: string;
  nicknameRegistered: string;
  nicknameAvailable: string;
  registerBtn: string;
  loginBtn: string;
  errorRequired: string;
  errorWrongCreds: string;
  errorFillAll: string;
  errorLength: string;
  errorExists: string;
  successRegister: string;
  successLogin: string;
}> = {
  ko: {
    selectLanguage: "조종석 시스템 언어 선택 (Language)",
    loginTitle: "조종실 로그인",
    registerTitle: "신규 조종사 회원가입",
    switchToRegister: "조종사 신규 등록 (가입)",
    switchToLogin: "이미 계정이 있습니까? 로그인",
    usernamePlaceholder: "조종사 닉네임 (3~8자)",
    passwordPlaceholder: "비밀번호",
    nicknameRegistered: "❌ 이미 등록된 닉네임 (사용 불가)",
    nicknameAvailable: "✅ 사용 가능한 닉네임",
    registerBtn: "조종사 등록 완료",
    loginBtn: "전투 제트기 탑승",
    errorRequired: "이름과 비밀번호를 입력해 주세요.",
    errorWrongCreds: "아이디 또는 비밀번호가 잘못되었습니다.",
    errorFillAll: "이름과 비밀번호를 채워주세요.",
    errorLength: "아이디는 3자에서 8자 사이의 영문/숫자여야 합니다.",
    errorExists: "이미 존재하는 조종사 명칭입니다. 다른 이름을 사용해 주세요.",
    successRegister: "새 조종사 등록 성공! 이제 로그인해 주세요.",
    successLogin: "로그인 성공!"
  },
  en: {
    selectLanguage: "Select Cockpit Language",
    loginTitle: "Cockpit Login",
    registerTitle: "Pilot Registration",
    switchToRegister: "Register New Pilot",
    switchToLogin: "Already have an account? Login",
    usernamePlaceholder: "Pilot Nickname (3-8 chars)",
    passwordPlaceholder: "Password",
    nicknameRegistered: "❌ Nickname already registered",
    nicknameAvailable: "✅ Nickname is available",
    registerBtn: "Complete Registration",
    loginBtn: "Board Battle Jet",
    errorRequired: "Please enter your name and password.",
    errorWrongCreds: "Invalid ID or password.",
    errorFillAll: "Please fill in both name and password.",
    errorLength: "ID must be between 3 and 8 characters.",
    errorExists: "This pilot name already exists. Please choose another.",
    successRegister: "New pilot registered! Please log in now.",
    successLogin: "Login successful!"
  },
  ja: {
    selectLanguage: "コックピット言語選択 (Language)",
    loginTitle: "コックピットログイン",
    registerTitle: "新規パイロット登録",
    switchToRegister: "パイロット新規登録 (加入)",
    switchToLogin: "アカウントをお持ちですか？ ログイン",
    usernamePlaceholder: "パイロット名 (3〜8文字)",
    passwordPlaceholder: "パスワード",
    nicknameRegistered: "❌ 登録済みの名前 (使用不可)",
    nicknameAvailable: "✅ 使用可能な名前",
    registerBtn: "パイロット登録完了",
    loginBtn: "戦闘機に搭乗",
    errorRequired: "名前とパスワードを入力してください。",
    errorWrongCreds: "ユーザー名またはパスワードが正しくありません。",
    errorFillAll: "名前とパスワードを入力してください。",
    errorLength: "IDは3文字から8文字の間である必要があります。",
    errorExists: "既に存在するパイロット名です。別の名前を使用してください。",
    successRegister: "新規パイロット登録成功！ログインしてください。",
    successLogin: "ログイン成功！"
  }
};

interface AuthPanelProps {
  currentUser: UserAccount | null;
  onLogin: (user: UserAccount) => void;
  onLogout: () => void;
  onSkinSelect: (skinId: string) => void;
}

export const AuthPanel: React.FC<AuthPanelProps> = ({
  currentUser,
  onLogin,
  onLogout,
  onSkinSelect,
}) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorKey, setErrorKey] = useState<'required' | 'wrongCreds' | 'fillAll' | 'length' | 'exists' | ''>('');
  const [successKey, setSuccessKey] = useState<'register' | 'login' | ''>('');
  const [language, setLanguage] = useState<Language>('ko');
  const [isDuplicate, setIsDuplicate] = useState(false);

  // Local sync
  const [localUser, setLocalUser] = useState<UserAccount | null>(currentUser);

  useEffect(() => {
    setLocalUser(currentUser);
  }, [currentUser]);

  const handleUsernameChange = (val: string) => {
    const rawVal = val.toUpperCase();
    setUsername(rawVal);
    
    if (isRegistering) {
      const trimmed = rawVal.trim();
      if (trimmed.length >= 3) {
        const accounts = loadAccounts();
        const exists = accounts.some(
          (acc) => acc.username.toLowerCase() === trimmed.toLowerCase()
        );
        setIsDuplicate(exists);
      } else {
        setIsDuplicate(false);
      }
    } else {
      setIsDuplicate(false);
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorKey('');
    setSuccessKey('');

    if (!username.trim() || !password.trim()) {
      setErrorKey('required');
      return;
    }

    const accounts = loadAccounts();
    const found = accounts.find(
      (acc) => acc.username.toLowerCase() === username.trim().toLowerCase()
    );

    if (!found || found.passwordHash !== password) {
      setErrorKey('wrongCreds');
      return;
    }

    sounds.playCoin();
    onLogin(found);
    setSuccessKey('login');
    // reset form
    setUsername('');
    setPassword('');
    setIsDuplicate(false);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorKey('');
    setSuccessKey('');

    const trimmedUser = username.trim().toUpperCase();
    if (!trimmedUser || !password.trim()) {
      setErrorKey('fillAll');
      return;
    }

    if (trimmedUser.length < 3 || trimmedUser.length > 8) {
      setErrorKey('length');
      return;
    }

    const accounts = loadAccounts();
    const exists = accounts.some(
      (acc) => acc.username.toLowerCase() === trimmedUser.toLowerCase()
    );

    if (exists || isDuplicate) {
      setErrorKey('exists');
      setIsDuplicate(true);
      return;
    }

    const newAccount: UserAccount = {
      username: trimmedUser,
      passwordHash: password,
      unlockedSkins: ['default'],
      selectedSkin: 'default',
      highScore: 0,
      coinsCollected: 100 // Welcome bonus of 100 coins!
    };

    accounts.push(newAccount);
    saveAccounts(accounts);

    sounds.playShield();
    setSuccessKey('register');
    setIsRegistering(false);
    setUsername(trimmedUser);
    setPassword('');
    setIsDuplicate(false);
  };

  // Buy Skin action
  const handleBuySkin = (skinId: string, cost: number) => {
    if (!currentUser) return;
    
    if (currentUser.coinsCollected < cost) {
      alert(`⚠️ 코인(Coins)이 부족합니다!\n현재 코인: ${currentUser.coinsCollected} / 필요 코인: ${cost}\n게임을 플레이하여 코인을 모아보세요.`);
      return;
    }

    const accounts = loadAccounts();
    const updated = accounts.map(acc => {
      if (acc.username.toLowerCase() === currentUser.username.toLowerCase()) {
        const skins = [...acc.unlockedSkins];
        if (!skins.includes(skinId)) {
          skins.push(skinId);
        }
        return {
          ...acc,
          coinsCollected: acc.coinsCollected - cost,
          unlockedSkins: skins
        };
      }
      return acc;
    });

    saveAccounts(updated);
    const updatedUser = updated.find(acc => acc.username.toLowerCase() === currentUser.username.toLowerCase());
    if (updatedUser) {
      onLogin(updatedUser);
      sounds.playShield();
      alert(`🎉 축하합니다! [${SKINS_LIST.find(s => s.id === skinId)?.name}] 스킨이 잠금해제되었습니다.`);
    }
  };

  const selectSkin = (skinId: string) => {
    if (!currentUser) return;

    const accounts = loadAccounts();
    const updated = accounts.map(acc => {
      if (acc.username.toLowerCase() === currentUser.username.toLowerCase()) {
        return {
          ...acc,
          selectedSkin: skinId
        };
      }
      return acc;
    });

    saveAccounts(updated);
    const updatedUser = updated.find(acc => acc.username.toLowerCase() === currentUser.username.toLowerCase());
    if (updatedUser) {
      onLogin(updatedUser);
      onSkinSelect(skinId);
      sounds.playLaneChange();
    }
  };

  const t = TRANSLATIONS[language];

  return (
    <div className="w-full bg-slate-900/60 backdrop-blur-md rounded-xl p-5 border border-white/10" id="auth-panel">
      
      {/* 1. NOT LOGGED IN VIEW */}
      {!currentUser ? (
        <div>
          {/* Language Selector */}
          <div className="mb-4 pb-3 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <span className="text-[11px] text-slate-400 font-sans tracking-wide">
              🌐 {t.selectLanguage}
            </span>
            <div className="flex gap-1.5">
              {(['ko', 'en', 'ja'] as Language[]).map((langCode) => {
                const label = langCode === 'ko' ? '🇰🇷 KO' : langCode === 'en' ? '🇺🇸 EN' : '🇯🇵 JA';
                const isSelected = language === langCode;
                return (
                  <button
                    key={langCode}
                    type="button"
                    onClick={() => {
                      setLanguage(langCode);
                      setErrorKey('');
                      setSuccessKey('');
                    }}
                    className={`px-2.5 py-1 rounded text-[10px] font-bold tracking-wider transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-500 text-slate-950 font-extrabold shadow-[0_0_8px_rgba(6,182,212,0.4)]'
                        : 'bg-slate-950/50 text-slate-400 border border-white/5 hover:border-white/15 hover:text-white'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex justify-between items-center mb-4">
            <h3 className="text-white font-sans font-semibold text-sm flex items-center gap-1.5">
              {isRegistering ? (
                <>
                  <UserPlus className="w-4 h-4 text-pink-400" />
                  {t.registerTitle}
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4 text-cyan-400" />
                  {t.loginTitle}
                </>
              )}
            </h3>
            
            <button
              onClick={() => {
                setIsRegistering(!isRegistering);
                setErrorKey('');
                setSuccessKey('');
                setUsername('');
                setPassword('');
                setIsDuplicate(false);
              }}
              className="text-[10px] text-cyan-400 hover:text-cyan-300 font-mono underline cursor-pointer"
            >
              {isRegistering ? t.switchToLogin : t.switchToRegister}
            </button>
          </div>

          <form onSubmit={isRegistering ? handleRegister : handleLogin} className="space-y-3">
            <div className="relative">
              <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
              <input
                type="text"
                required
                placeholder={t.usernamePlaceholder}
                value={username}
                onChange={(e) => handleUsernameChange(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-950/80 border border-white/10 rounded-lg text-white font-mono text-sm placeholder-slate-600 focus:outline-none focus:border-cyan-400"
                maxLength={8}
              />
              {isRegistering && username.trim().length >= 3 && (
                <div className="mt-1 text-[11px] font-mono pl-1">
                  {isDuplicate ? (
                    <span className="text-red-400 font-semibold">{t.nicknameRegistered}</span>
                  ) : (
                    <span className="text-emerald-400 font-semibold">{t.nicknameAvailable}</span>
                  )}
                </div>
              )}
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
              <input
                type="password"
                required
                placeholder={t.passwordPlaceholder}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-950/80 border border-white/10 rounded-lg text-white font-mono text-sm placeholder-slate-600 focus:outline-none focus:border-cyan-400"
              />
            </div>

            {errorKey && (
              <p className="text-red-400 text-[10px] font-mono bg-red-950/30 py-1.5 px-2.5 rounded border border-red-500/20 text-center">
                {t[`error${errorKey.charAt(0).toUpperCase() + errorKey.slice(1)}` as keyof typeof t]}
              </p>
            )}

            {successKey && (
              <p className="text-emerald-400 text-[10px] font-mono bg-emerald-950/30 py-1.5 px-2.5 rounded border border-emerald-500/20 text-center">
                {t[`success${successKey.charAt(0).toUpperCase() + successKey.slice(1)}` as keyof typeof t]}
              </p>
            )}

            <button
              type="submit"
              className={`w-full py-2.5 rounded-lg text-xs font-bold tracking-wider uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                isRegistering 
                  ? 'bg-pink-500 hover:bg-pink-400 text-slate-950' 
                  : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950'
              }`}
            >
              {isRegistering ? t.registerBtn : t.loginBtn}
            </button>
          </form>
        </div>
      ) : (
        
        // 2. LOGGED IN VIEW (Skins & Stats)
        <div className="space-y-4">
          <div className="flex justify-between items-start border-b border-white/5 pb-3">
            <div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_6px_#10b981]" />
                <span className="text-white font-bold text-sm tracking-wider">{currentUser.username}</span>
                <span className="text-[10px] text-slate-500 uppercase font-mono">PILOT ONLINE</span>
              </div>
              <div className="flex items-center gap-3 mt-1.5">
                <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                  <Trophy className="w-3 h-3 text-amber-500" />
                  최고점: <span className="text-white font-bold">{currentUser.highScore.toLocaleString()}</span>
                </span>
                <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                  <Coins className="w-3 h-3 text-amber-400" />
                  코인: <span className="text-amber-400 font-bold">{currentUser.coinsCollected}</span>
                </span>
              </div>
            </div>

            <button
              onClick={onLogout}
              className="px-2 py-1 bg-slate-950 hover:bg-red-950/20 hover:text-red-400 border border-white/5 rounded text-[10px] font-mono text-slate-500 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <LogOut className="w-3 h-3" /> 로그아웃
            </button>
          </div>

          {/* SKINS SELECTION SECTION */}
          <div>
            <h4 className="text-slate-300 font-sans text-xs font-semibold mb-2 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> 함선 스킨 선택기 (외형 교체)
            </h4>

            <div className="space-y-2">
              {SKINS_LIST.filter(skin => skin.id !== 'dev_exclusive' || (currentUser?.username.toUpperCase() === 'AKS13551')).map((skin) => {
                const isUnlocked = currentUser.unlockedSkins.includes(skin.id);
                const isSelected = currentUser.selectedSkin === skin.id;
                
                // Buying conditions
                const isBuyable = skin.id === 'gold_cyber';
                const price = 500;

                return (
                  <div
                    key={skin.id}
                    className={`p-2.5 rounded-lg border text-left transition-all ${
                      isSelected
                        ? 'bg-slate-950 border-cyan-500/70 shadow-[0_0_10px_rgba(6,182,212,0.1)]'
                        : isUnlocked
                        ? 'bg-slate-950/40 border-white/5 hover:border-white/10'
                        : 'bg-slate-950/25 border-white/5 opacity-75'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <div 
                            className="w-2.5 h-2.5 rounded-full" 
                            style={{ 
                              backgroundColor: skin.secondaryColor,
                              boxShadow: `0 0 6px ${skin.glowColor}`
                            }} 
                          />
                          <span className="text-white font-bold text-xs">{skin.name}</span>
                          {isSelected && (
                            <span className="text-[9px] px-1 bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 rounded font-bold">
                              선택됨
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1 leading-normal">{skin.description}</p>
                        <p className="text-[9px] text-slate-500 font-mono mt-0.5">해제 방법: {skin.howToUnlock}</p>
                      </div>

                      <div className="pl-2">
                        {isUnlocked ? (
                          !isSelected && (
                            <button
                              onClick={() => selectSkin(skin.id)}
                              className="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-white/10 rounded text-[9px] font-bold text-cyan-400 cursor-pointer"
                            >
                              적용
                            </button>
                          )
                        ) : isBuyable ? (
                          <button
                            onClick={() => handleBuySkin(skin.id, price)}
                            className="px-2 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded text-[9px] font-bold flex items-center gap-0.5 cursor-pointer shadow-[0_0_6px_rgba(245,158,11,0.3)]"
                          >
                            <Coins className="w-2.5 h-2.5" /> 500개 구매
                          </button>
                        ) : (
                          <span className="text-[9px] text-slate-600 font-mono flex items-center gap-0.5">
                            🔒 잠김
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
