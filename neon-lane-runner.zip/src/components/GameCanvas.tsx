import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GamePhase, GameItem, Particle, Lane, ItemType, GameStats } from '../types';
import { sounds } from '../utils/audio';

interface GameCanvasProps {
  phase: GamePhase;
  onStatsChange: (stats: GameStats) => void;
  onGameOver: (finalScore: number) => void;
  isPaused: boolean;
  selectedSkinId?: string;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  phase,
  onStatsChange,
  onGameOver,
  isPaused,
  selectedSkinId = 'default',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Size tracking
  const [dimensions, setDimensions] = useState({ width: 600, height: 800 });

  // Game state stored in refs to prevent React re-render lag during 60fps loop
  const statsRef = useRef<GameStats>({
    score: 0,
    coins: 0,
    distance: 0,
    multiplier: 1,
    multiplierEndTime: 0,
    shieldActive: false,
    shieldEndTime: 0,
    lives: 3,
    speed: 8, // base speed
  });

  const playerLaneRef = useRef<Lane>(1);
  const playerXRef = useRef<number>(300); // Lerped position
  const itemsRef = useRef<GameItem[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const gridOffsetYRef = useRef<number>(0);
  const starsRef = useRef<{ x: number; y: number; speed: number; size: number }[]>([]);
  
  // VFX state
  const shakeTimeRef = useRef<number>(0);
  const shakeIntensityRef = useRef<number>(0);
  const flashAlphaRef = useRef<number>(0);

  // Timers and spawn control
  const lastSpawnTimeRef = useRef<number>(0);
  const gameTimeRef = useRef<number>(0);
  const animationFrameIdRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);

  // Resize observer for responsive canvas sizing
  useEffect(() => {
    if (!containerRef.current) return;

    const observer = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width, height } = entries[0].contentRect;
      setDimensions({
        width: Math.max(width, 300),
        height: Math.max(height, 400),
      });
    });

    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Sync canvas attributes with state dimensions
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = dimensions.width;
    canvas.height = dimensions.height;
    
    // Position player initially
    if (phase === 'MENU') {
      playerXRef.current = dimensions.width / 2;
    }
  }, [dimensions, phase]);

  // Generate background stars once
  useEffect(() => {
    const stars = [];
    for (let i = 0; i < 60; i++) {
      stars.push({
        x: Math.random() * 800, // proportional width space
        y: Math.random() * 1000,
        speed: Math.random() * 1.5 + 0.5,
        size: Math.random() * 2 + 0.5,
      });
    }
    starsRef.current = stars;
  }, []);

  // Helper: Reset game stats and objects
  const resetGame = () => {
    statsRef.current = {
      score: 0,
      coins: 0,
      distance: 0,
      multiplier: 1,
      multiplierEndTime: 0,
      shieldActive: false,
      shieldEndTime: 0,
      lives: 3,
      speed: 8,
    };
    playerLaneRef.current = 1;
    playerXRef.current = dimensions.width / 2;
    itemsRef.current = [];
    particlesRef.current = [];
    gridOffsetYRef.current = 0;
    shakeTimeRef.current = 0;
    flashAlphaRef.current = 0;
    lastSpawnTimeRef.current = 0;
    gameTimeRef.current = 0;
    lastTimeRef.current = performance.now();
    
    onStatsChange({ ...statsRef.current });
  };

  // Spawn dynamic particles
  const spawnParticle = useCallback((
    x: number,
    y: number,
    vx: number,
    vy: number,
    color: string,
    size: number,
    maxLife: number
  ) => {
    particlesRef.current.push({
      x,
      y,
      vx,
      vy,
      color,
      size,
      life: maxLife,
      maxLife,
      alpha: 1,
    });
  }, []);

  // Keyboard and click interactions
  const changeLane = useCallback((direction: 'left' | 'right') => {
    if (phase !== 'PLAYING' || isPaused) return;

    const currentLane = playerLaneRef.current;
    let nextLane = currentLane;

    if (direction === 'left' && currentLane > 0) {
      nextLane = (currentLane - 1) as Lane;
    } else if (direction === 'right' && currentLane < 2) {
      nextLane = (currentLane + 1) as Lane;
    }

    if (nextLane !== currentLane) {
      playerLaneRef.current = nextLane;
      sounds.playLaneChange();
      
      // Spawn tiny thrust trail
      const roadWidth = Math.min(dimensions.width, 500);
      const roadX = (dimensions.width - roadWidth) / 2;
      const laneWidth = roadWidth / 3;
      const currentX = roadX + laneWidth * (currentLane + 0.5);
      
      for (let i = 0; i < 8; i++) {
        spawnParticle(
          currentX,
          dimensions.height * 0.82,
          (direction === 'left' ? 3 : -3) + (Math.random() * 2 - 1),
          Math.random() * 2 - 1,
          '#00f0ff',
          Math.random() * 3 + 1,
          20
        );
      }
    }
  }, [phase, isPaused, dimensions, spawnParticle]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore keypresses if the user is typing in inputs or form fields
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA' ||
        document.activeElement?.hasAttribute('contenteditable')
      ) {
        return;
      }

      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        e.preventDefault(); // Prevent page scrolls or default focus shifts
        changeLane('left');
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        e.preventDefault(); // Prevent page scrolls or default focus shifts
        changeLane('right');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [changeLane]);

  // Handle touch and click splits
  const handleCanvasInteraction = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (phase !== 'PLAYING' || isPaused) return;

    let clientX = 0;
    if ('touches' in e) {
      if (e.touches.length === 0) return;
      clientX = e.touches[0].clientX;
    } else {
      clientX = e.clientX;
    }

    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const clickX = clientX - rect.left;
    const canvasMid = rect.width / 2; // Fixed: Use visual screen element width midpoint instead of layout buffer width!

    if (clickX < canvasMid) {
      changeLane('left');
    } else {
      changeLane('right');
    }
  };

  const spawnBurst = (x: number, y: number, color: string, count: number = 15, baseSpeed: number = 4) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * baseSpeed + 1;
      spawnParticle(
        x,
        y,
        Math.cos(angle) * speed,
        Math.sin(angle) * speed,
        color,
        Math.random() * 4 + 1.5,
        Math.random() * 30 + 15
      );
    }
  };

  // Reset game state on phase transition to MENU or PLAYING
  useEffect(() => {
    if (phase === 'MENU' || phase === 'PLAYING') {
      resetGame();
    }
  }, [phase]);

  // Main game logic loops
  useEffect(() => {
    if (phase !== 'PLAYING') {
      // Draw background animation static loop when on menu or gameover
      let lastLoop = 0;
      const staticLoop = (now: number) => {
        if (phase !== 'MENU' && phase !== 'GAMEOVER') return;
        const delta = now - lastLoop;
        if (delta > 16) {
          drawStatic(now);
          lastLoop = now;
        }
        animationFrameIdRef.current = requestAnimationFrame(staticLoop);
      };
      animationFrameIdRef.current = requestAnimationFrame(staticLoop);
      return () => cancelAnimationFrame(animationFrameIdRef.current);
    }

    // Main Active Game loop
    const gameLoop = (time: number) => {
      if (isPaused) {
        lastTimeRef.current = time;
        animationFrameIdRef.current = requestAnimationFrame(gameLoop);
        return;
      }

      const deltaTime = Math.min(time - lastTimeRef.current, 100); // Caps delta
      lastTimeRef.current = time;

      update(deltaTime);
      render();

      animationFrameIdRef.current = requestAnimationFrame(gameLoop);
    };

    animationFrameIdRef.current = requestAnimationFrame(gameLoop);

    return () => {
      cancelAnimationFrame(animationFrameIdRef.current);
    };
  }, [phase, isPaused, dimensions]);

  // UPDATE STATE ENVELOPE
  const update = (dt: number) => {
    gameTimeRef.current += dt;
    const nowTimestamp = Date.now();

    const stats = statsRef.current;
    
    // Multiplier & Shield expiration tracking
    if (stats.shieldActive && nowTimestamp > stats.shieldEndTime) {
      stats.shieldActive = false;
    }
    if (stats.multiplier > 1 && nowTimestamp > stats.multiplierEndTime) {
      stats.multiplier = 1;
    }

    // Gradually speed up based on distance
    const distanceGain = (stats.speed / 60) * (dt / 16.6); // roughly meters
    stats.distance += distanceGain;
    
    // Scale speed carefully up to max speed 20
    const nextSpeed = 8 + Math.floor(stats.distance / 120) * 1.5;
    if (nextSpeed !== stats.speed && nextSpeed <= 22) {
      stats.speed = nextSpeed;
      sounds.playSpeedUp();
      flashAlphaRef.current = 0.4; // Speed rise alert glow
    }

    // Auto passive score gain based on speed and distance
    stats.score += Math.round((stats.speed * 0.1) * stats.multiplier);

    // Grid scroll offset
    gridOffsetYRef.current = (gridOffsetYRef.current + stats.speed) % 100;

    // Calculate road and lanes
    const roadWidth = Math.min(dimensions.width, 500);
    const roadX = (dimensions.width - roadWidth) / 2;
    const laneWidth = roadWidth / 3;

    // Smoothly lerp player visual X position to target lane
    const targetX = roadX + laneWidth * (playerLaneRef.current + 0.5);
    playerXRef.current += (targetX - playerXRef.current) * 0.22; // Quick, fluid slide!

    // Item Spawner Logic
    if (gameTimeRef.current - lastSpawnTimeRef.current > Math.max(800, 2000 - stats.speed * 80)) {
      spawnItem(stats.speed);
      lastSpawnTimeRef.current = gameTimeRef.current;
    }

    // Update existing items
    const screenHeight = dimensions.height;
    itemsRef.current = itemsRef.current.filter((item) => {
      // Advance coordinates downwards
      item.y += (stats.speed * 0.4) * (dt / 16.6); // speed scaled

      // Dynamic item animation pulse
      item.pulseScale = 1 + Math.sin(gameTimeRef.current * 0.01 + parseInt(item.id, 16) * 0.1) * 0.12;

      // Handle off-screen removals
      if (item.y > screenHeight + 50) {
        return false;
      }

      // 💥 COLLISION DETECTION (at player y point ~ 80%)
      const playerY = screenHeight * 0.8;
      const playerRadius = 22;
      const itemX = roadX + laneWidth * (item.lane + 0.5);
      const itemY = item.y;

      const dx = playerXRef.current - itemX;
      const dy = playerY - itemY;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < playerRadius + item.width * 0.55) {
        handleCollision(item);
        return false; // delete item on collision
      }

      return true;
    });

    // Update Particles
    particlesRef.current = particlesRef.current.filter((p) => {
      p.x += p.vx;
      p.y += p.vy;
      p.life -= 1;
      p.alpha = p.life / p.maxLife;
      return p.life > 0;
    });

    // Update Screen shake
    if (shakeTimeRef.current > 0) {
      shakeTimeRef.current -= dt;
    }

    // Sync state change notification
    onStatsChange({ ...stats });
  };

  // Spawn items in randomized configurations
  const spawnItem = (currentSpeed: number) => {
    // Lanes configuration (0, 1, 2)
    const laneOptions: Lane[] = [0, 1, 2];
    const chosenLane = laneOptions[Math.floor(Math.random() * laneOptions.length)];

    // Randomized type weighting
    const rand = Math.random();
    let type: ItemType = 'OBSTACLE';
    let color = '#ff0055'; // neon pink danger

    if (rand < 0.52) {
      type = 'OBSTACLE';
      color = '#ff0055';
    } else if (rand < 0.88) {
      type = 'COIN';
      color = '#ffd700'; // shiny neon gold
    } else if (rand < 0.94) {
      type = 'SHIELD';
      color = '#00f0ff'; // cyber cyan
    } else {
      type = 'MULTIPLIER';
      color = '#bf55ec'; // neon electric violet
    }

    // Avoid clustering power-ups directly.
    // If obstacle, occasionally spawn double obstacles at higher speeds
    const id = Math.floor(Math.random() * 1000000).toString(16);
    
    itemsRef.current.push({
      id,
      lane: chosenLane,
      y: -40,
      type,
      color,
      width: type === 'OBSTACLE' ? 26 : 22,
      height: type === 'OBSTACLE' ? 26 : 22,
      pulseScale: 1,
    });

    // Multi-obstacle challenge generator on higher speeds
    if (type === 'OBSTACLE' && currentSpeed > 11 && Math.random() < 0.35) {
      const remainingLanes = laneOptions.filter((l) => l !== chosenLane);
      const extraLane = remainingLanes[Math.floor(Math.random() * remainingLanes.length)];
      const extraId = Math.floor(Math.random() * 1000000).toString(16);
      
      itemsRef.current.push({
        id: extraId,
        lane: extraLane,
        y: -40,
        type: 'OBSTACLE',
        color: '#ff0055',
        width: 26,
        height: 26,
        pulseScale: 1,
      });
    }
  };

  // Handle precise collision outcomes
  const handleCollision = (item: GameItem) => {
    const stats = statsRef.current;
    const roadWidth = Math.min(dimensions.width, 500);
    const roadX = (dimensions.width - roadWidth) / 2;
    const laneWidth = roadWidth / 3;
    const collX = roadX + laneWidth * (item.lane + 0.5);
    const collY = item.y;

    if (item.type === 'COIN') {
      stats.coins += 1;
      stats.score += 20 * stats.multiplier;
      sounds.playCoin();
      spawnBurst(collX, collY, '#ffd700', 12, 5);
    } else if (item.type === 'SHIELD') {
      stats.shieldActive = true;
      stats.shieldEndTime = Date.now() + 8000; // 8 seconds of absolute shield
      sounds.playShield();
      spawnBurst(collX, collY, '#00f0ff', 16, 6);
    } else if (item.type === 'MULTIPLIER') {
      stats.multiplier = 2;
      stats.multiplierEndTime = Date.now() + 8000; // 8 seconds of x2 scoring
      sounds.playMultiplier();
      spawnBurst(collX, collY, '#bf55ec', 16, 6);
    } else if (item.type === 'OBSTACLE') {
      if (stats.shieldActive) {
        // Shield absorbs the crash impact
        stats.shieldActive = false;
        stats.shieldEndTime = 0;
        sounds.playCrash();
        shakeTimeRef.current = 200; // mild shake
        shakeIntensityRef.current = 6;
        spawnBurst(collX, collY, '#00f0ff', 25, 8); // shield explosion color
      } else {
        // Direct crash
        stats.lives -= 1;
        sounds.playCrash();
        shakeTimeRef.current = 350; // intense shake
        shakeIntensityRef.current = 14;
        flashAlphaRef.current = 0.6; // screen flashes red warning
        spawnBurst(collX, collY, '#ff0055', 30, 9); // explosion sparks
        
        // Reset any existing streak multiplier
        stats.multiplier = 1;
        stats.multiplierEndTime = 0;

        if (stats.lives <= 0) {
          sounds.playGameOver();
          onGameOver(stats.score);
        }
      }
    }

    onStatsChange({ ...stats });
  };

  // STATIC DRAW (Menu, Gameover, static elements)
  const drawStatic = (time: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { width, height } = dimensions;

    // Clear Canvas with rich cyber void dark-gradient
    const grad = ctx.createLinearGradient(0, 0, 0, height);
    grad.addColorStop(0, '#060112');
    grad.addColorStop(1, '#0c0424');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    // Dynamic menu screen starfield movement
    ctx.save();
    starsRef.current.forEach((star) => {
      star.y = (star.y + star.speed * 0.2) % height;
      ctx.fillStyle = `rgba(180, 220, 255, ${0.4 + Math.sin(time * 0.001 + star.x) * 0.3})`;
      ctx.beginPath();
      ctx.arc((star.x / 800) * width, star.y, star.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();

    // Render decorative vertical scrolling lane grids
    drawRoadGrid(ctx, width, height, (time * 0.04) % 100);
  };

  // COMMON: Road track, grid lines background
  const drawRoadGrid = (ctx: CanvasRenderingContext2D, width: number, height: number, offsetY: number) => {
    const roadWidth = Math.min(width, 500);
    const roadX = (width - roadWidth) / 2;
    const laneWidth = roadWidth / 3;

    // Draw cybernetically-styled grid lanes
    ctx.save();
    
    // Draw outer road backdrop
    ctx.fillStyle = 'rgba(10, 5, 25, 0.45)';
    ctx.fillRect(roadX, 0, roadWidth, height);

    // Draw glowing side lane dividers
    ctx.lineWidth = 2;
    ctx.shadowBlur = 10;
    
    // Draw lane lines
    for (let i = 0; i <= 3; i++) {
      const x = roadX + i * laneWidth;
      
      ctx.strokeStyle = i === 0 || i === 3 
        ? 'rgba(0, 240, 255, 0.6)'  // outer boundary glowing cyan
        : 'rgba(255, 0, 85, 0.22)'; // inner separators deep neon pink
      ctx.shadowColor = i === 0 || i === 3 ? '#00f0ff' : '#ff0055';
      
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    // Horizontal sliding gridlines inside the road tracks (speed indicators)
    ctx.shadowBlur = 0;
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.09)';
    ctx.lineWidth = 1;
    for (let y = offsetY; y < height; y += 80) {
      ctx.beginPath();
      ctx.moveTo(roadX, y);
      ctx.lineTo(roadX + roadWidth, y);
      ctx.stroke();
    }
    
    ctx.restore();
  };

  // MAIN RUNTIME RENDER LOOP
  const render = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { width, height } = dimensions;

    ctx.save();

    // Handle high-impact Screen Shake
    if (shakeTimeRef.current > 0) {
      const shakeAmt = shakeIntensityRef.current;
      const dx = (Math.random() - 0.5) * shakeAmt;
      const dy = (Math.random() - 0.5) * shakeAmt;
      ctx.translate(dx, dy);
    }

    // 1. Draw Space background & static starry layer
    const grad = ctx.createLinearGradient(0, 0, 0, height);
    grad.addColorStop(0, '#060112');
    grad.addColorStop(1, '#0c0424');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    // Render flowing background stars with parallax layer speed ratios
    starsRef.current.forEach((star) => {
      // parallax scrolling relative to player ship forward speed
      star.y = (star.y + star.speed * (statsRef.current.speed * 0.12)) % height;
      ctx.fillStyle = `rgba(255, 255, 255, ${0.4 + Math.sin(gameTimeRef.current * 0.002 + star.x) * 0.3})`;
      ctx.beginPath();
      ctx.arc((star.x / 800) * width, star.y, star.size, 0, Math.PI * 2);
      ctx.fill();
    });

    // 2. Draw Lane Track grids
    drawRoadGrid(ctx, width, height, gridOffsetYRef.current);

    // 3. Draw Items (Coins, Powerups, Obstacles)
    const roadWidth = Math.min(width, 500);
    const roadX = (width - roadWidth) / 2;
    const laneWidth = roadWidth / 3;

    itemsRef.current.forEach((item) => {
      const x = roadX + laneWidth * (item.lane + 0.5);
      const y = item.y;

      ctx.save();
      ctx.translate(x, y);

      // Add a nice cybernetic glow
      ctx.shadowBlur = 15;
      ctx.shadowColor = item.color;

      const size = item.width * item.pulseScale;

      if (item.type === 'COIN') {
        // Draw golden spinning cyber diamond
        ctx.fillStyle = '#ffd700';
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        
        ctx.beginPath();
        ctx.moveTo(0, -size * 0.6);
        ctx.lineTo(size * 0.45, 0);
        ctx.lineTo(0, size * 0.6);
        ctx.lineTo(-size * 0.45, 0);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Inner glowing core
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0, 0, size * 0.15, 0, Math.PI * 2);
        ctx.fill();

      } else if (item.type === 'SHIELD') {
        // Draw cyber blue energy crystal sphere
        const rad = size * 0.5;
        const outerGrad = ctx.createRadialGradient(0, 0, 1, 0, 0, rad);
        outerGrad.addColorStop(0, '#ffffff');
        outerGrad.addColorStop(0.3, 'rgba(0, 240, 255, 0.8)');
        outerGrad.addColorStop(1, 'rgba(0, 240, 255, 0)');
        
        ctx.fillStyle = outerGrad;
        ctx.beginPath();
        ctx.arc(0, 0, rad, 0, Math.PI * 2);
        ctx.fill();

        // Protective ring overlay
        ctx.strokeStyle = '#00f0ff';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 0, rad * 0.75, 0, Math.PI * 2);
        ctx.stroke();

        // Shield plus icon
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-4, 0); ctx.lineTo(4, 0);
        ctx.moveTo(0, -4); ctx.lineTo(0, 4);
        ctx.stroke();

      } else if (item.type === 'MULTIPLIER') {
        // Draw glowing golden purple star
        ctx.fillStyle = '#bf55ec';
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;

        ctx.beginPath();
        for (let i = 0; i < 5; i++) {
          ctx.lineTo(Math.cos((18 + i * 72) * Math.PI / 180) * (size * 0.6),
                     Math.sin((18 + i * 72) * Math.PI / 180) * (size * 0.6));
          ctx.lineTo(Math.cos((54 + i * 72) * Math.PI / 180) * (size * 0.25),
                     Math.sin((54 + i * 72) * Math.PI / 180) * (size * 0.25));
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Overlay text: "2X"
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 10px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('2X', 0, 0);

      } else if (item.type === 'OBSTACLE') {
        // Draw geometric neon red spike mine
        const spikes = 6;
        const innerRad = size * 0.3;
        const outerRad = size * 0.6;

        ctx.fillStyle = '#ff0055';
        ctx.strokeStyle = '#ffccd5';
        ctx.lineWidth = 1.5;

        ctx.beginPath();
        for (let i = 0; i < spikes * 2; i++) {
          const r = i % 2 === 0 ? outerRad : innerRad;
          const angle = (i * Math.PI) / spikes;
          ctx.lineTo(Math.cos(angle) * r, Math.sin(angle) * r);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Inner core flashing
        const pulseRatio = (Math.sin(gameTimeRef.current * 0.02) + 1) / 2;
        ctx.fillStyle = `rgba(255, 255, 255, ${0.4 + pulseRatio * 0.6})`;
        ctx.beginPath();
        ctx.arc(0, 0, innerRad * 0.65, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    });

    // 4. Draw Particles (sparks and debris)
    particlesRef.current.forEach((p) => {
      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });

    // 5. Draw Player Vessel (Spaceship)
    const pY = height * 0.8;
    const pX = playerXRef.current;
    
    ctx.save();
    ctx.translate(pX, pY);

    // Glowing shield overlay (if active)
    if (statsRef.current.shieldActive) {
      const shieldPulse = 1 + Math.sin(gameTimeRef.current * 0.015) * 0.06;
      ctx.save();
      ctx.shadowBlur = 20;
      ctx.shadowColor = '#00f0ff';
      ctx.lineWidth = 3;
      
      // Draw outer glowing bubble
      const gradient = ctx.createRadialGradient(0, 0, 18, 0, 0, 32);
      gradient.addColorStop(0, 'rgba(0, 240, 255, 0)');
      gradient.addColorStop(0.7, 'rgba(0, 240, 255, 0.15)');
      gradient.addColorStop(1, 'rgba(0, 240, 255, 0.7)');
      ctx.fillStyle = gradient;
      
      ctx.beginPath();
      ctx.arc(0, 0, 30 * shieldPulse, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.strokeStyle = 'rgba(0, 240, 255, 0.8)';
      ctx.stroke();
      ctx.restore();
    }

    // Engine flame flicker trail
    let bodyFillColor = '#0a0a18';
    let glowColor = '#00f0ff';
    let detailsColor = '#ff0055';

    if (selectedSkinId === 'gold_cyber') {
      bodyFillColor = '#1a1505';
      glowColor = '#ffd700';
      detailsColor = '#ff7700';
    } else if (selectedSkinId === 'champion_phantom') {
      bodyFillColor = '#0d0115';
      glowColor = '#ff00aa';
      detailsColor = '#bf55ec';
    } else if (selectedSkinId === 'dev_exclusive') {
      bodyFillColor = '#020f04';
      glowColor = '#39ff14';
      detailsColor = '#00ff66';
    } else if (selectedSkinId === 'champ_3wins') {
      bodyFillColor = '#030d22';
      glowColor = '#00ffff';
      detailsColor = '#0088ff';
    } else if (selectedSkinId === 'champ_5wins') {
      bodyFillColor = '#220d03';
      glowColor = '#ff7700';
      detailsColor = '#ffaa00';
    } else if (selectedSkinId === 'champ_7wins') {
      bodyFillColor = '#03221d';
      glowColor = '#00ffcc';
      detailsColor = '#00cca3';
    } else if (selectedSkinId === 'champ_10wins') {
      bodyFillColor = '#0c0012';
      glowColor = '#e0115f';
      detailsColor = '#ff003c';
    }

    ctx.save();
    const flameHeight = 12 + Math.random() * 12 + (statsRef.current.speed * 0.5);
    const flameGrad = ctx.createLinearGradient(0, 12, 0, 12 + flameHeight);
    flameGrad.addColorStop(0, glowColor); // Primary skin flame core
    flameGrad.addColorStop(0.5, detailsColor); // Details middle
    flameGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = flameGrad;
    ctx.shadowBlur = 10;
    ctx.shadowColor = detailsColor;
    ctx.beginPath();
    ctx.moveTo(-5, 12);
    ctx.lineTo(0, 12 + flameHeight);
    ctx.lineTo(5, 12);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // Player Cyber Jet body
    ctx.save();
    ctx.shadowBlur = 18;
    ctx.shadowColor = glowColor;
    ctx.fillStyle = bodyFillColor;
    ctx.strokeStyle = glowColor;
    ctx.lineWidth = 2;

    // Outer triangular wing structure
    ctx.beginPath();
    ctx.moveTo(0, -18);      // Nose tip
    ctx.lineTo(16, 12);      // Right wing bottom
    ctx.lineTo(7, 7);        // Right thrust indent
    ctx.lineTo(-7, 7);       // Left thrust indent
    ctx.lineTo(-16, 12);     // Left wing bottom
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Inner glowing lines (cockpit, highlights)
    ctx.strokeStyle = detailsColor; // dynamic details indicators
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, -9);
    ctx.lineTo(3, 4);
    ctx.lineTo(-3, 4);
    ctx.closePath();
    ctx.stroke();

    ctx.restore();
    ctx.restore(); // restore player state

    // 6. Impact Fullscreen Flash effects (for crashes or visual cues)
    if (flashAlphaRef.current > 0) {
      ctx.fillStyle = `rgba(255, 0, 85, ${flashAlphaRef.current})`;
      ctx.fillRect(0, 0, width, height);
      flashAlphaRef.current -= 0.035; // fade away slowly
    }

    ctx.restore(); // restore global shake translations
  };

  return (
    <div 
      ref={containerRef} 
      className="relative w-full h-full min-h-[400px] flex items-center justify-center bg-slate-950 overflow-hidden rounded-xl border border-white/10"
    >
      <canvas
        ref={canvasRef}
        onClick={handleCanvasInteraction}
        onTouchStart={handleCanvasInteraction}
        className="block cursor-pointer select-none touch-none bg-slate-950 max-h-[100%]"
        id="game-canvas"
      />
      {phase === 'PLAYING' && (
        <div className="absolute top-4 left-4 text-white/40 text-[10px] font-mono select-none pointer-events-none tracking-wider">
          TAP LEFT / RIGHT SIDE OR USE [A] [D] / [←] [→]
        </div>
      )}
    </div>
  );
};
