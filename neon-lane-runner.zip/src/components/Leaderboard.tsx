import React, { useState, useEffect } from 'react';
import { ScoreRecord, UserAccount, SeasonState } from '../types';
import { Trophy, Calendar, Zap, Trash2, Clock, ShieldAlert, Sparkles } from 'lucide-react';
import { sounds } from '../utils/audio';
import { getScoresForSeason, getDaysLeftInCurrentMonth, getSeasonState, forceSeasonReset, resetToSeasonOne, loadAccounts, saveAccounts } from '../utils/seasonManager';

interface LeaderboardProps {
  currentSeason: number;
  currentUser: UserAccount | null;
  onSeasonEnded: (nextState: SeasonState) => void;
  scoreToSubmit?: number;
  maxMultiplierReached?: number;
  onScoreSubmitted?: () => void;
  inline?: boolean;
}

const LOCAL_STORAGE_KEY = 'neon_runner_high_scores';

export const Leaderboard: React.FC<LeaderboardProps> = ({
  currentSeason,
  currentUser,
  onSeasonEnded,
  scoreToSubmit,
  maxMultiplierReached = 1,
  onScoreSubmitted,
  inline = false,
}) => {
  const [scores, setScores] = useState<ScoreRecord[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [timeText, setTimeText] = useState('00일 00시 00분 00초');
  const [seasonState, setSeasonState] = useState<SeasonState | null>(null);

  // Custom alert/confirm states to bypass iframe sandboxing constraints
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const [showConfirmSeasonOne, setShowConfirmSeasonOne] = useState(false);
  const [showConfirmClear, setShowConfirmClear] = useState(false);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);

  // Sync / Load scores
  useEffect(() => {
    loadSeasonAndScores();
  }, [currentSeason, scoreToSubmit]);

  const loadSeasonAndScores = () => {
    const sState = getSeasonState();
    setSeasonState(sState);
    const seasonScores = getScoresForSeason(currentSeason);
    setScores(seasonScores);
  };

  // Timer tick for season end
  useEffect(() => {
    const updateTimer = () => {
      const nowSState = getSeasonState();
      const { days, hours, minutes, seconds } = getDaysLeftInCurrentMonth(nowSState.endsAt);
      
      const dStr = days.toString().padStart(2, '0');
      const hStr = hours.toString().padStart(2, '0');
      const mStr = minutes.toString().padStart(2, '0');
      const sStr = seconds.toString().padStart(2, '0');
      
      setTimeText(`${dStr}일 ${hStr}시간 ${mStr}분 ${sStr}초`);

      // Check auto-reset if month passes
      if (nowSState.currentSeason !== currentSeason) {
        onSeasonEnded(nowSState);
        loadSeasonAndScores();
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [currentSeason]);

  // Submit high score
  useEffect(() => {
    if (scoreToSubmit !== undefined && scoreToSubmit > 0 && currentUser && !submitted) {
      // Auto register the score under logged in user's name
      const newRecord: ScoreRecord = {
        id: Math.random().toString(36).substring(2, 9),
        name: currentUser.username.toUpperCase(),
        score: scoreToSubmit,
        date: new Date().toLocaleDateString('ko-KR', { year: '2-digit', month: '2-digit', day: '2-digit' }),
        maxMultiplier: maxMultiplierReached,
        seasonNumber: currentSeason
      };

      try {
        const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
        let currentScores: ScoreRecord[] = stored ? JSON.parse(stored) : [];

        // Find if this specific player already has a record for the current season
        const existingIdx = currentScores.findIndex(
          s => s.name.toUpperCase() === currentUser.username.toUpperCase() && s.seasonNumber === currentSeason
        );

        let didLeaderboardUpdate = false;

        if (existingIdx !== -1) {
          // If the player has a record, only replace it if the new score is higher
          if (scoreToSubmit > currentScores[existingIdx].score) {
            currentScores[existingIdx] = newRecord;
            didLeaderboardUpdate = true;
          }
        } else {
          // No record exists yet, so we append the new high score
          currentScores.push(newRecord);
          didLeaderboardUpdate = true;
        }

        if (didLeaderboardUpdate) {
          localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(currentScores));
        }

        // Always update user account stats & award run coins even if it didn't top the season record
        const accounts = loadAccounts();
        const updatedAccounts = accounts.map(acc => {
          if (acc.username.toLowerCase() === currentUser.username.toLowerCase()) {
            return {
              ...acc,
              highScore: Math.max(acc.highScore, scoreToSubmit),
              coinsCollected: acc.coinsCollected + Math.round(scoreToSubmit / 100) // reward some coins!
            };
          }
          return acc;
        });
        saveAccounts(updatedAccounts);

        // Update active scores in component view state
        setScores(currentScores.filter(s => s.seasonNumber === currentSeason).sort((a, b) => b.score - a.score));
        setSubmitted(true);
        sounds.playHighScore();

        if (onScoreSubmitted) {
          onScoreSubmitted();
        }
      } catch (err) {
        console.error('Error auto-saving score:', err);
      }
    }
  }, [scoreToSubmit, currentUser, currentSeason]);

  const handleForceNextSeason = () => {
    setShowConfirmReset(true);
  };

  const confirmForceNextSeason = () => {
    const nextState = forceSeasonReset();
    onSeasonEnded(nextState);
    setSubmitted(false);
    loadSeasonAndScores();
    setShowConfirmReset(false);
    setAlertMessage(`🎉 시즌이 정상 종료되었습니다!\n새로운 시즌 ${nextState.currentSeason}이 개막했습니다!`);
  };

  const handleResetToSeasonOne = () => {
    setShowConfirmSeasonOne(true);
  };

  const confirmResetToSeasonOne = () => {
    const resetState = resetToSeasonOne();
    onSeasonEnded(resetState);
    setSubmitted(false);
    loadSeasonAndScores();
    setShowConfirmSeasonOne(false);
    setAlertMessage('🔄 성공적으로 시즌 1로 리셋되었습니다!');
  };

  const clearLeaderboard = () => {
    setShowConfirmClear(true);
  };

  const confirmClearLeaderboard = () => {
    localStorage.removeItem(LOCAL_STORAGE_KEY);
    setScores([]);
    setShowConfirmClear(false);
    setAlertMessage('🗑️ 이번 시즌 모든 리더보드 기록이 성공적으로 초기화되었습니다.');
  };

  return (
    <div className={`w-full bg-slate-900/60 backdrop-blur-md rounded-xl p-5 border border-white/10 ${inline ? '' : 'shadow-2xl'}`} id="game-leaderboard">
      
      {/* Custom Confirmation Modals / Alerts */}
      {showConfirmReset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-pink-500/30 rounded-xl p-6 max-w-sm w-full shadow-2xl text-center space-y-4 animate-in fade-in zoom-in duration-200">
            <div className="mx-auto w-12 h-12 bg-pink-500/10 rounded-full flex items-center justify-center text-pink-400">
              <Sparkles className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h4 className="text-white font-bold text-base">즉시 시즌 종료 시뮬레이션</h4>
              <p className="text-slate-400 text-xs mt-2 leading-relaxed">
                정말로 즉시 시즌을 종료하고 다음 시즌으로 전환하시겠습니까? <br/>
                현재 1위 플레이어가 전용 <span className="text-pink-400 font-semibold">[챔피언 스킨]</span>을 획득하게 됩니다!
              </p>
            </div>
            <div className="flex gap-2.5">
              <button
                onClick={() => setShowConfirmReset(false)}
                className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg font-mono transition-colors cursor-pointer"
              >
                취소
              </button>
              <button
                onClick={confirmForceNextSeason}
                className="flex-1 py-2 bg-pink-600 hover:bg-pink-500 text-white text-xs rounded-lg font-mono font-bold transition-colors cursor-pointer"
              >
                시즌 종료 진행
              </button>
            </div>
          </div>
        </div>
      )}

      {showConfirmClear && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-red-500/30 rounded-xl p-6 max-w-sm w-full shadow-2xl text-center space-y-4 animate-in fade-in zoom-in duration-200">
            <div className="mx-auto w-12 h-12 bg-red-500/10 rounded-full flex items-center justify-center text-red-400">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-white font-bold text-base">리더보드 전체 삭제</h4>
              <p className="text-slate-400 text-xs mt-2 leading-relaxed">
                정말로 이번 시즌 모든 리더보드 기록을 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.
              </p>
            </div>
            <div className="flex gap-2.5">
              <button
                onClick={() => setShowConfirmClear(false)}
                className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg font-mono transition-colors cursor-pointer"
              >
                취소
              </button>
              <button
                onClick={confirmClearLeaderboard}
                className="flex-1 py-2 bg-red-600 hover:bg-red-500 text-white text-xs rounded-lg font-mono font-bold transition-colors cursor-pointer"
              >
                전체 삭제
              </button>
            </div>
          </div>
        </div>
      )}

      {showConfirmSeasonOne && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-purple-500/30 rounded-xl p-6 max-w-sm w-full shadow-2xl text-center space-y-4 animate-in fade-in zoom-in duration-200">
            <div className="mx-auto w-12 h-12 bg-purple-500/10 rounded-full flex items-center justify-center text-purple-400">
              <Sparkles className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h4 className="text-white font-bold text-base">시즌 1로 리셋</h4>
              <p className="text-slate-400 text-xs mt-2 leading-relaxed">
                정말로 시즌 정보를 초기화하고 **시즌 1**로 돌아가시겠습니까? <br/>
                역대 우승자 히스토리도 초기화됩니다.
              </p>
            </div>
            <div className="flex gap-2.5">
              <button
                onClick={() => setShowConfirmSeasonOne(false)}
                className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg font-mono transition-colors cursor-pointer"
              >
                취소
              </button>
              <button
                onClick={confirmResetToSeasonOne}
                className="flex-1 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs rounded-lg font-mono font-bold transition-colors cursor-pointer"
              >
                시즌 1 리셋 진행
              </button>
            </div>
          </div>
        </div>
      )}

      {alertMessage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-cyan-500/30 rounded-xl p-6 max-w-sm w-full shadow-2xl text-center space-y-4 animate-in fade-in zoom-in duration-200">
            <div className="mx-auto w-12 h-12 bg-cyan-500/10 rounded-full flex items-center justify-center text-cyan-400">
              <Trophy className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <h4 className="text-white font-bold text-base">알림</h4>
              <p className="text-slate-300 text-xs mt-2 whitespace-pre-line leading-relaxed">
                {alertMessage}
              </p>
            </div>
            <button
              onClick={() => setAlertMessage(null)}
              className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs rounded-lg font-mono font-bold transition-colors cursor-pointer"
            >
              확인
            </button>
          </div>
        </div>
      )}

      {/* SEASON TIMER BLOCK */}
      <div className="mb-4 bg-gradient-to-r from-pink-950/40 to-purple-950/40 p-3 rounded-lg border border-pink-500/20 text-center flex flex-col items-center justify-center gap-1">
        <div className="flex items-center gap-1 text-pink-400 text-[10px] font-mono tracking-widest uppercase">
          <Clock className="w-3 h-3 animate-spin" style={{ animationDuration: '6s' }} />
          이번 시즌 {currentSeason} 종료 카운트다운
        </div>
        <div className="text-white text-base font-bold font-mono tracking-wider">
          {timeText}
        </div>
        
        {/* Season Admin Simulation Triggers - Exclusive to AKS13551 */}
        {!inline && currentUser?.username.toUpperCase() === 'AKS13551' && (
          <div className="flex flex-col gap-1.5 mt-2 w-full">
            <button
              onClick={handleForceNextSeason}
              className="px-2.5 py-1 bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/30 rounded text-[10px] text-pink-300 font-mono transition-colors cursor-pointer flex items-center justify-center gap-1"
            >
              <Sparkles className="w-3 h-3" /> 시즌 즉시 종료 시뮬레이션 (1등 스킨 지급)
            </button>
            <button
              onClick={handleResetToSeasonOne}
              className="px-2.5 py-1 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 rounded text-[10px] text-purple-300 font-mono transition-colors cursor-pointer flex items-center justify-center gap-1"
            >
              <Clock className="w-3 h-3" /> 시즌 1로 되돌리기 (기록/역사 초기화)
            </button>
          </div>
        )}
      </div>

      {/* Auto score notify */}
      {scoreToSubmit !== undefined && scoreToSubmit > 0 && !currentUser && (
        <div className="mb-4 bg-amber-950/40 p-3 rounded-lg border border-amber-500/30 text-center">
          <p className="text-amber-400 text-xs font-semibold">⚠️ 로그인이 필요합니다</p>
          <p className="text-slate-300 text-[11px] mt-0.5">회원가입 후 로그인하여 {scoreToSubmit.toLocaleString()}점의 기록을 보관해 보세요!</p>
        </div>
      )}

      {scoreToSubmit !== undefined && scoreToSubmit > 0 && currentUser && submitted && (
        <div className="mb-4 bg-cyan-950/40 p-3 rounded-lg border border-cyan-500/30 text-center">
          <p className="text-cyan-400 text-xs font-bold">🎉 기록 자동 등록 성공!</p>
          <p className="text-slate-300 text-[11px] mt-0.5">{currentUser.username}님의 소중한 우주 비행 점수 {scoreToSubmit.toLocaleString()}점이 전송되었습니다.</p>
        </div>
      )}

      {/* LEADERBOARD HEADER */}
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-white font-sans font-semibold tracking-tight text-sm flex items-center gap-1.5">
          <Trophy className="w-4 h-4 text-amber-400" />
          시즌 {currentSeason} 순위판
        </h3>
        
        {scores.length > 0 && !inline && (
          <button
            onClick={clearLeaderboard}
            className="text-slate-500 hover:text-red-400 p-1 rounded transition-colors cursor-pointer"
            title="기록 초기화"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* NO AI BOTS EMPTY NOTICE */}
      {scores.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <ShieldAlert className="w-8 h-8 text-slate-600 mb-1.5" />
          <p className="text-slate-400 text-xs font-medium">이번 시즌의 비행 기록이 아직 없습니다!</p>
          <p className="text-slate-500 text-[10px] mt-0.5 font-mono">AI 봇이 제외된 리얼 유저 리그입니다.</p>
        </div>
      ) : (
        <div className="space-y-1 max-h-[250px] overflow-y-auto pr-1">
          {scores.map((record, index) => {
            const isTop3 = index < 3;
            const rankColors = [
              'text-amber-400 shadow-amber-500/10',
              'text-slate-300 shadow-slate-300/10',
              'text-amber-600 shadow-amber-700/10',
            ];
            
            return (
              <div
                key={record.id}
                className={`flex items-center justify-between py-1.5 px-3 rounded-lg text-xs font-mono transition-all ${
                  isTop3 
                    ? 'bg-slate-950/60 border border-white/5 shadow-inner' 
                    : 'bg-transparent border border-transparent'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className={`font-bold w-4 text-center ${isTop3 ? rankColors[index] : 'text-slate-500'}`}>
                    {index + 1}
                  </span>
                  <span className={`font-bold tracking-widest ${isTop3 ? 'text-white' : 'text-slate-300'}`}>
                    {record.name}
                  </span>
                  {record.maxMultiplier > 1 && (
                    <span className="text-[9px] px-1 bg-purple-500/20 text-purple-400 rounded flex items-center gap-0.5">
                      <Zap className="w-2.5 h-2.5" /> 2X
                    </span>
                  )}
                  {index === 0 && (
                    <span className="text-[9px] px-1 bg-pink-500/20 text-pink-400 border border-pink-500/30 rounded font-bold font-sans">
                      👑 1등 스킨 대상
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-slate-600 text-[9px] flex items-center gap-0.5">
                    <Calendar className="w-2.5 h-2.5" />
                    {record.date}
                  </span>
                  <span className={`font-semibold ${isTop3 ? 'text-cyan-400 font-bold text-sm' : 'text-slate-300'}`}>
                    {record.score.toLocaleString()}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Previous Champions History */}
      {seasonState && seasonState.history && seasonState.history.length > 0 && (
        <div className="mt-4 pt-3 border-t border-white/5 text-left">
          <p className="text-slate-400 text-[10px] font-mono tracking-wider uppercase mb-1.5">역대 우승자 기록</p>
          <div className="space-y-1">
            {seasonState.history.slice(0, 3).map((hist) => (
              <div key={hist.season} className="flex justify-between items-center text-[10px] font-mono text-slate-500">
                <span>시즌 {hist.season} 챔피언</span>
                <span className="text-pink-400 font-bold">{hist.champion || '기록 없음'} ({hist.winningScore.toLocaleString()}점)</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
