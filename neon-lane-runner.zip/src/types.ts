export type GamePhase = 'MENU' | 'PLAYING' | 'PAUSED' | 'GAMEOVER';

export type Lane = 0 | 1 | 2;

export type ItemType = 'OBSTACLE' | 'COIN' | 'SHIELD' | 'MULTIPLIER';

export interface GameItem {
  id: string;
  lane: Lane;
  y: number; // percentage from top (0 to 100)
  type: ItemType;
  color: string;
  width: number;
  height: number;
  pulseScale: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
  maxLife: number;
  alpha: number;
}

export interface ScoreRecord {
  id: string;
  name: string;
  score: number;
  date: string;
  maxMultiplier: number;
  seasonNumber: number;
}

export interface GameStats {
  score: number;
  coins: number;
  distance: number; // in meters
  multiplier: number;
  multiplierEndTime: number; // timestamp when x2 expires
  shieldActive: boolean;
  shieldEndTime: number; // timestamp when shield expires
  lives: number;
  speed: number;
}

export interface UserAccount {
  username: string;
  passwordHash: string; // local simple plaintext for mock auth
  unlockedSkins: string[];
  selectedSkin: string;
  highScore: number;
  coinsCollected: number;
}

export interface SeasonState {
  currentSeason: number;
  endsAt: number; // timestamp
  previousChampion: string | null;
  history: {
    season: number;
    champion: string | null;
    winningScore: number;
  }[];
}

export type SkinId = 'default' | 'gold_cyber' | 'champion_phantom' | 'dev_exclusive' | 'champ_3wins' | 'champ_5wins' | 'champ_7wins' | 'champ_10wins';

export interface SkinDefinition {
  id: SkinId;
  name: string;
  primaryColor: string;
  secondaryColor: string;
  glowColor: string;
  description: string;
  howToUnlock: string;
}

