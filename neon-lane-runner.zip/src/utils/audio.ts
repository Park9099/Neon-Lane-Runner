// Retro Synthesized Audio Engine using Web Audio API

let audioCtx: AudioContext | null = null;
let isMuted = false;
let masterVolume = 0.3;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    // Standard AudioContext initialization
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  
  return audioCtx;
}

export const setMuted = (muted: boolean) => {
  isMuted = muted;
};

export const getMuted = () => {
  return isMuted;
};

export const setVolume = (vol: number) => {
  masterVolume = Math.max(0, Math.min(1, vol));
};

export const getVolume = () => {
  return masterVolume;
};

// Play a short synth note
const playTone = (
  freqs: number[], 
  durations: number[], 
  type: OscillatorType = 'sine', 
  glide = false
) => {
  if (isMuted) return;
  
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    
    // Gain node for envelope
    const gainNode = ctx.createGain();
    gainNode.connect(ctx.destination);
    
    // Start silent
    gainNode.gain.setValueAtTime(0, now);
    
    // Create oscillator
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.connect(gainNode);
    
    let time = now;
    freqs.forEach((freq, idx) => {
      const dur = durations[idx] || 0.1;
      if (idx === 0) {
        osc.frequency.setValueAtTime(freq, time);
        // Quick fade-in to prevent clicking
        gainNode.gain.linearRampToValueAtTime(masterVolume, time + 0.01);
      } else {
        if (glide) {
          osc.frequency.exponentialRampToValueAtTime(freq, time + dur);
        } else {
          osc.frequency.setValueAtTime(freq, time);
        }
      }
      time += dur;
    });
    
    // Fade out at the end
    gainNode.gain.exponentialRampToValueAtTime(0.0001, time);
    
    osc.start(now);
    osc.stop(time + 0.05);
  } catch (error) {
    console.warn('Audio play failed:', error);
  }
};

// Sound effects catalog
export const sounds = {
  // Coin collection: ascending shiny notes
  playCoin: () => {
    playTone([523.25, 659.25, 783.99, 1046.50], [0.05, 0.05, 0.05, 0.1], 'triangle');
  },
  
  // Lane Change: quick swoop whoosh
  playLaneChange: () => {
    playTone([220, 440], [0.08], 'sine', true);
  },
  
  // Hit / Obstacle: low rumble/explosion
  playCrash: () => {
    if (isMuted) return;
    try {
      const ctx = getAudioContext();
      const now = ctx.currentTime;
      
      const bufferSize = ctx.sampleRate * 0.25; // quarter of a second
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      
      // Generate noise
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      
      const noiseNode = ctx.createBufferSource();
      noiseNode.buffer = buffer;
      
      // Filter the noise for a bassy rumble
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(150, now);
      filter.frequency.exponentialRampToValueAtTime(30, now + 0.25);
      
      const gainNode = ctx.createGain();
      gainNode.gain.setValueAtTime(masterVolume * 1.5, now);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
      
      noiseNode.connect(filter);
      filter.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      noiseNode.start(now);
      noiseNode.stop(now + 0.3);
    } catch (e) {
      // Fallback
      playTone([120, 60], [0.1, 0.15], 'sawtooth', true);
    }
  },
  
  // Shield pickup: high tech sci-fi sweep
  playShield: () => {
    playTone([400, 800, 1600], [0.08, 0.08, 0.15], 'sine', true);
  },
  
  // Multiplier x2: twin chime
  playMultiplier: () => {
    playTone([587.33, 587.33, 880.00], [0.06, 0.04, 0.15], 'triangle');
  },
  
  // Game Over: retro descending sad tones
  playGameOver: () => {
    playTone([392.00, 349.23, 311.13, 261.63, 196.00], [0.15, 0.15, 0.15, 0.15, 0.3], 'sawtooth');
  },
  
  // High Score unlock / Victory celebration
  playHighScore: () => {
    playTone([523.25, 659.25, 783.99, 1046.50, 783.99, 1046.50, 1318.51], [0.08, 0.08, 0.08, 0.08, 0.08, 0.08, 0.3], 'triangle');
  },
  
  // Speed Up: quick riser
  playSpeedUp: () => {
    playTone([300, 600], [0.15], 'sine', true);
  }
};
