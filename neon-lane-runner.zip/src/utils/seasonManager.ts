import { UserAccount, SeasonState, ScoreRecord } from '../types';

const SEASON_STORAGE_KEY = 'neon_runner_season_info';
const ACCOUNTS_STORAGE_KEY = 'neon_runner_accounts';
const HIGH_SCORES_KEY = 'neon_runner_high_scores';

// Helper to get calendar days left in the current month or a specified endsAt timestamp
export function getDaysLeftInCurrentMonth(endsAt?: number): { days: number; hours: number; minutes: number; seconds: number } {
  const now = Date.now();
  
  // If endsAt is not specified, default to the first day of next month
  let targetTime = endsAt;
  if (!targetTime) {
    const d = new Date();
    targetTime = new Date(d.getFullYear(), d.getMonth() + 1, 1).getTime();
  }
  
  const diffMs = targetTime - now;
  const totalSecs = Math.max(0, Math.floor(diffMs / 1000));
  const days = Math.floor(totalSecs / (3600 * 24));
  const hours = Math.floor((totalSecs % (3600 * 24)) / 3600);
  const minutes = Math.floor((totalSecs % 3600) / 60);
  const seconds = totalSecs % 60;
  
  return { days, hours, minutes, seconds };
}

// Load accounts
export function loadAccounts(): UserAccount[] {
  const data = localStorage.getItem(ACCOUNTS_STORAGE_KEY);
  if (!data) return [];
  try {
    const accounts: UserAccount[] = JSON.parse(data);
    let changed = false;

    // Get season history safely to count wins without recursion
    let history: { champion: string | null }[] = [];
    const seasonData = localStorage.getItem(SEASON_STORAGE_KEY);
    if (seasonData) {
      try {
        const stateObj = JSON.parse(seasonData);
        if (stateObj && Array.isArray(stateObj.history)) {
          history = stateObj.history;
        }
      } catch (err) {}
    }

    const updated = accounts.map(acc => {
      const uName = acc.username.toUpperCase();
      const skins = [...acc.unlockedSkins];
      let skinChanged = false;

      // AKS13551 exclusive: Unlock all available skins
      if (uName === 'AKS13551') {
        const allPossibleSkins = [
          'default',
          'gold_cyber',
          'champion_phantom',
          'dev_exclusive',
          'champ_3wins',
          'champ_5wins',
          'champ_7wins',
          'champ_10wins'
        ];
        allPossibleSkins.forEach(sk => {
          if (!skins.includes(sk)) {
            skins.push(sk);
            skinChanged = true;
          }
        });
      }

      // Count wins in history for other players
      const winsCount = history.filter(h => h.champion?.toUpperCase() === uName).length;
      if (winsCount >= 3 && !skins.includes('champ_3wins')) {
        skins.push('champ_3wins');
        skinChanged = true;
      }
      if (winsCount >= 5 && !skins.includes('champ_5wins')) {
        skins.push('champ_5wins');
        skinChanged = true;
      }
      if (winsCount >= 7 && !skins.includes('champ_7wins')) {
        skins.push('champ_7wins');
        skinChanged = true;
      }
      if (winsCount >= 10 && !skins.includes('champ_10wins')) {
        skins.push('champ_10wins');
        skinChanged = true;
      }

      if (skinChanged) {
        changed = true;
        return { ...acc, unlockedSkins: skins };
      }
      return acc;
    });

    if (changed) {
      localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(updated));
      return updated;
    }
    return accounts;
  } catch (e) {
    return [];
  }
}

// Save accounts
export function saveAccounts(accounts: UserAccount[]) {
  // Get season history safely to count wins without recursion
  let history: { champion: string | null }[] = [];
  const seasonData = localStorage.getItem(SEASON_STORAGE_KEY);
  if (seasonData) {
    try {
      const stateObj = JSON.parse(seasonData);
      if (stateObj && Array.isArray(stateObj.history)) {
        history = stateObj.history;
      }
    } catch (err) {}
  }

  const updated = accounts.map(acc => {
    const uName = acc.username.toUpperCase();
    const skins = [...acc.unlockedSkins];
    let changed = false;

    // AKS13551 exclusive: Unlock all available skins
    if (uName === 'AKS13551') {
      const allPossibleSkins = [
        'default',
        'gold_cyber',
        'champion_phantom',
        'dev_exclusive',
        'champ_3wins',
        'champ_5wins',
        'champ_7wins',
        'champ_10wins'
      ];
      allPossibleSkins.forEach(sk => {
        if (!skins.includes(sk)) {
          skins.push(sk);
          changed = true;
        }
      });
    }

    // Count wins in history for other players
    const winsCount = history.filter(h => h.champion?.toUpperCase() === uName).length;
    if (winsCount >= 3 && !skins.includes('champ_3wins')) {
      skins.push('champ_3wins');
      changed = true;
    }
    if (winsCount >= 5 && !skins.includes('champ_5wins')) {
      skins.push('champ_5wins');
      changed = true;
    }
    if (winsCount >= 7 && !skins.includes('champ_7wins')) {
      skins.push('champ_7wins');
      changed = true;
    }
    if (winsCount >= 10 && !skins.includes('champ_10wins')) {
      skins.push('champ_10wins');
      changed = true;
    }

    if (changed) {
      return { ...acc, unlockedSkins: skins };
    }
    return acc;
  });

  localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(updated));
}

// Get scores
export function getScoresForSeason(season: number): ScoreRecord[] {
  const data = localStorage.getItem(HIGH_SCORES_KEY);
  if (!data) return [];
  try {
    const scores: ScoreRecord[] = JSON.parse(data);
    // Filter by season and exclude developer AKS13551
    return scores
      .filter(s => s.seasonNumber === season && s.name.toUpperCase() !== 'AKS13551')
      .sort((a, b) => b.score - a.score);
  } catch (e) {
    return [];
  }
}

// Get active season info
export function getSeasonState(): SeasonState {
  const data = localStorage.getItem(SEASON_STORAGE_KEY);
  if (data) {
    try {
      const state: SeasonState = JSON.parse(data);
      // Auto transition checking if calendar month has changed
      const now = Date.now();
      if (now > state.endsAt) {
        return transitionToNextSeason(state);
      }
      return state;
    } catch (e) {
      // fallback
    }
  }

  // Calculate first endsAt (end of current month)
  const now = new Date();
  const endsAt = new Date(now.getFullYear(), now.getMonth() + 1, 1).getTime();
  const initial: SeasonState = {
    currentSeason: 1,
    endsAt,
    previousChampion: null,
    history: []
  };
  localStorage.setItem(SEASON_STORAGE_KEY, JSON.stringify(initial));
  return initial;
}

// Save season state
export function saveSeasonState(state: SeasonState) {
  localStorage.setItem(SEASON_STORAGE_KEY, JSON.stringify(state));
}

// Advance Season and Reward Champion
export function transitionToNextSeason(currentState: SeasonState): SeasonState {
  // Get high scores for the ending season
  const endingSeason = currentState.currentSeason;
  const seasonScores = getScoresForSeason(endingSeason);
  
  let championName: string | null = null;
  let winningScore = 0;

  if (seasonScores.length > 0) {
    const topRecord = seasonScores[0];
    championName = topRecord.name;
    winningScore = topRecord.score;

    // Reward skin to the champion account if it exists
    const accounts = loadAccounts();
    const championAccount = accounts.find(acc => acc.username.toUpperCase() === championName?.toUpperCase());
    if (championAccount) {
      if (!championAccount.unlockedSkins.includes('champion_phantom')) {
        championAccount.unlockedSkins.push('champion_phantom');
      }
      saveAccounts(accounts);
    }
  }

  // Set new end time: 30 days from now to start a fresh countdown for the new season
  const nextEndsAt = Date.now() + 30 * 24 * 60 * 60 * 1000;

  const nextState: SeasonState = {
    currentSeason: endingSeason + 1,
    endsAt: nextEndsAt,
    previousChampion: championName,
    history: [
      {
        season: endingSeason,
        champion: championName,
        winningScore
      },
      ...currentState.history
    ]
  };

  saveSeasonState(nextState);
  return nextState;
}

// Manually trigger season reset (useful for testing or simulation)
export function forceSeasonReset(): SeasonState {
  const currentState = getSeasonState();
  return transitionToNextSeason(currentState);
}

// Manually reset back to Season 1
export function resetToSeasonOne(): SeasonState {
  // Set endsAt to 30 days from now to start a fresh countdown for Season 1
  const endsAt = Date.now() + 30 * 24 * 60 * 60 * 1000;
  const resetState: SeasonState = {
    currentSeason: 1,
    endsAt,
    previousChampion: null,
    history: []
  };
  saveSeasonState(resetState);
  return resetState;
}
